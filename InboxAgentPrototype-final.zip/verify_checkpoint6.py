"""End-to-end verification for checkpoint 6. Not part of the app.

Uses FastAPI's TestClient (starlette/httpx under the hood) to exercise
the real app object exactly as ASGI would, without needing a separately
running server process.
"""
from fastapi.testclient import TestClient

from backend.app.main import app
from backend.app.audit import _reset_for_tests as reset_audit
from backend.app.escalations import _reset_for_tests as reset_escalations

reset_audit()
reset_escalations()

client = TestClient(app)


def check(label, cond):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {label}")
    assert cond, label


def post_message(message, **kwargs):
    payload = {"message": message, **kwargs}
    resp = client.post("/api/messages", json=payload)
    return resp


print("=" * 78)
print("GET /health")
r = client.get("/health")
print(r.status_code, r.json())
check("health 200", r.status_code == 200)

print("=" * 78)
print("Case 1 — delivery #1048")
r1 = post_message("Porosia #1048 ende s'ka ardhur. Kanë kaluar 6 ditë.")
print(r1.status_code)
print(r1.json())
b1 = r1.json()
check("case1 status 200", r1.status_code == 200)
check("case1 language sq", b1["language"] == "sq")
check("case1 intent delivery_status", b1["intent"] == "delivery_status")
check("case1 decision AUTO", b1["decision"] == "AUTO")
check("case1 reported_days_elapsed is 6 (unconverted)", b1["entities"]["reported_days_elapsed"] == 6)
delivery_policy_call = next(c for c in b1["tool_calls"] if c["tool"] == "lookup_policy")
check(
    "case1 delivery policy window is 2-4 working days, kept separate from the '6 days' fact",
    delivery_policy_call["result"]["window_days_min"] == 2
    and delivery_policy_call["result"]["window_days_max"] == 4
    and delivery_policy_call["result"]["unit"] == "working days",
)
check("case1 reply mentions the 6-day report", "6" in b1["reply"])
check("case1 reply does not call it '6 working days'", "6 working days" not in b1["reply"].lower())
check("case1 escalation is null", b1["escalation"] is None)

print("=" * 78)
print("Case 2 — return, 45 days, box open")
r2 = post_message("Can I return headphones after 45 days? Box is open.")
print(r2.status_code)
print(r2.json())
b2 = r2.json()
check("case2 status 200", r2.status_code == 200)
check("case2 decision HUMAN", b2["decision"] == "HUMAN")
check(
    "case2 reply does not promise an exception or refund",
    "we'll refund" not in b2["reply"].lower() and "we will make an exception" not in b2["reply"].lower(),
)
check("case2 reply explicitly says can't promise refund/exception", "can't promise" in b2["reply"].lower())
check("case2 escalation created", b2["escalation"] is not None)
check("case2 escalation status open", b2["escalation"]["status"] == "open")

print("=" * 78)
print("Case 3 — repeated broken laptop complaint")
r3 = post_message("3rd time writing! Laptop broken, NOBODY answers!!")
print(r3.status_code)
print(r3.json())
b3 = r3.json()
check("case3 status 200", r3.status_code == 200)
check("case3 decision HUMAN", b3["decision"] == "HUMAN")
check("case3 escalation created", b3["escalation"] is not None)
check(
    "case3 reply does not falsely claim resolution (allows 'has not been resolved')",
    "has been resolved" not in b3["reply"].lower() and "issue resolved" not in b3["reply"].lower(),
)

print("=" * 78)
print("Case 4 — unauthorized address request #1031")
r4 = post_message("Arben's brother here. What's the address on order #1031?")
print(r4.status_code)
print(r4.json())
b4 = r4.json()
check("case4 status 200", r4.status_code == 200)
check("case4 decision VERIFY", b4["decision"] == "VERIFY")
check("case4 no address anywhere in the response body", "rruga" not in str(b4).lower())
check("case4 escalation is null (VERIFY, not HUMAN)", b4["escalation"] is None)
audit4 = client.get(f"/api/audit/{b4['request_id']}").json()
check("case4 no address anywhere in the audit record", "rruga" not in str(audit4).lower())

print("=" * 78)
print("Case 5 — installment question")
r5 = post_message("A mund ta blej laptopin me këste?")
print(r5.status_code)
print(r5.json())
b5 = r5.json()
check("case5 status 200", r5.status_code == 200)
check("case5 language sq", b5["language"] == "sq")
check("case5 decision UNKNOWN", b5["decision"] == "UNKNOWN")
check(
    "case5 reply does not invent financing numbers (no % or 'months' figure)",
    "%" not in b5["reply"] and "monthly payment" not in b5["reply"].lower(),
)

print("=" * 78)
print("Adversarial case — mixed/ambiguous intent")
r6 = post_message("I want to return my laptop but also what's the address on order #1031?")
print(r6.status_code)
print(r6.json())
b6 = r6.json()
check("adversarial status 200 (no crash)", r6.status_code == 200)
check("adversarial intent stays unknown (conflicting signals)", b6["intent"] == "unknown")
check("adversarial decision UNKNOWN", b6["decision"] == "UNKNOWN")
check("adversarial no address leaked despite order id present", "rruga" not in str(b6).lower())

print("=" * 78)
print("GET /api/escalations")
resp_esc = client.get("/api/escalations")
print(resp_esc.status_code, resp_esc.json())
check("escalations list status 200", resp_esc.status_code == 200)
check("escalations list has exactly 2 entries (case 2 and case 3)", len(resp_esc.json()) == 2)

print("=" * 78)
print("GET /api/audit/{request_id} — known id")
resp_audit_known = client.get(f"/api/audit/{b1['request_id']}")
print(resp_audit_known.status_code, resp_audit_known.json())
check("audit known id status 200", resp_audit_known.status_code == 200)
check("audit known id request_id matches", resp_audit_known.json()["request_id"] == b1["request_id"])

print("=" * 78)
print("GET /api/audit/{request_id} — unknown id")
resp_audit_unknown = client.get("/api/audit/req-999999")
print(resp_audit_unknown.status_code, resp_audit_unknown.json())
check("audit unknown id status 404", resp_audit_unknown.status_code == 404)

print("\nALL CHECKS PASSED")
