"""Ad-hoc verification for checkpoint 7 (reply.py wording fix). Not part of the app.

Covers, as requested:
- installment UNKNOWN
- an unclear/mixed-intent UNKNOWN
- a delivery UNKNOWN result
- the existing HUMAN cases still accurately say they were escalated
"""
from fastapi.testclient import TestClient

from backend.app.main import app
from backend.app.audit import _reset_for_tests as reset_audit
from backend.app.escalations import _reset_for_tests as reset_escalations

reset_audit()
reset_escalations()
client = TestClient(app)


def check(label, cond):
    status = "PASS" if cond else "FAIL"
    print(f"[{status}] {label}")
    assert cond, label


def post(message):
    return client.post("/api/messages", json={"message": message})


# Phrases that claim a handoff happened / will happen. Checked case-
# insensitively, in both languages.
HANDOFF_PHRASES = [
    "forward",  # forwarded / forwarding
    "team member",
    "someone from our team",
    "someone on our team",
    "will review",
    "will take a look",
    "përcjell",  # Albanian: "we've forwarded" (përcjellim / përcjellë)
    "po i kalohet",  # Albanian: "is being passed to"
    "ekipi do ta shqyrtojë",  # Albanian: "the team will review it"
    "dikush nga ekipi",  # Albanian: "someone from the team"
]


def assert_no_handoff_claim(label, reply_text):
    lowered = reply_text.lower()
    for phrase in HANDOFF_PHRASES:
        check(f"{label}: reply does not claim '{phrase}'", phrase not in lowered)


def assert_has_handoff_claim(label, reply_text, lang):
    lowered = reply_text.lower()
    if lang == "sq":
        found = "përcjell" in lowered or "po i kalohet" in lowered or "kalohet" in lowered
    else:
        found = "forward" in lowered or "escalated" in lowered or "team member" in lowered
    check(f"{label}: reply DOES claim a handoff (escalation exists)", found)


print("=" * 78)
print("Case A — installment_purchase (UNKNOWN, no escalation)")
rA = post("A mund ta blej laptopin me këste?")
bA = rA.json()
print(bA["decision"], "|", bA["reply"])
check("caseA status 200", rA.status_code == 200)
check("caseA decision UNKNOWN", bA["decision"] == "UNKNOWN")
check("caseA no escalation object", bA["escalation"] is None)
assert_no_handoff_claim("caseA", bA["reply"])
check("caseA reply directs to contact the shop", "kontaktoni dyqanin" in bA["reply"].lower())

print("=" * 78)
print("Case B — unclear/mixed-intent message (UNKNOWN, no escalation)")
rB = post("I want to return my laptop but also what's the address on order #1031?")
bB = rB.json()
print(bB["decision"], "|", bB["reply"])
check("caseB status 200", rB.status_code == 200)
check("caseB intent unknown", bB["intent"] == "unknown")
check("caseB decision UNKNOWN", bB["decision"] == "UNKNOWN")
check("caseB no escalation object", bB["escalation"] is None)
assert_no_handoff_claim("caseB", bB["reply"])
check("caseB reply directs to contact the shop", "contact the shop" in bB["reply"].lower())

print("=" * 78)
print("Case C — delivery_status UNKNOWN (unknown order id, no escalation)")
rC = post("My order number is 9999, where is it?")
bC = rC.json()
print(bC["decision"], "|", bC["reply"])
check("caseC status 200", rC.status_code == 200)
check("caseC intent delivery_status", bC["intent"] == "delivery_status")
check("caseC decision UNKNOWN", bC["decision"] == "UNKNOWN")
check("caseC no escalation object", bC["escalation"] is None)
assert_no_handoff_claim("caseC", bC["reply"])
check("caseC reply directs to contact the shop", "contact the shop" in bC["reply"].lower())

print("=" * 78)
print("Case D — return_request HUMAN (escalation SHOULD exist and be claimed)")
rD = post("Can I return headphones after 45 days? Box is open.")
bD = rD.json()
print(bD["decision"], "|", bD["reply"])
check("caseD status 200", rD.status_code == 200)
check("caseD decision HUMAN", bD["decision"] == "HUMAN")
check("caseD escalation object present", bD["escalation"] is not None)
assert_has_handoff_claim("caseD", bD["reply"], bD["language"])
check("caseD does not promise a refund/exception", "we'll refund" not in bD["reply"].lower())

print("=" * 78)
print("Case E — damaged_product HUMAN (escalation SHOULD exist and be claimed)")
rE = post("3rd time writing! Laptop broken, NOBODY answers!!")
bE = rE.json()
print(bE["decision"], "|", bE["reply"])
check("caseE status 200", rE.status_code == 200)
check("caseE decision HUMAN", bE["decision"] == "HUMAN")
check("caseE escalation object present", bE["escalation"] is not None)
assert_has_handoff_claim("caseE", bE["reply"], bE["language"])
check("caseE does not falsely claim resolution", "has been resolved" not in bE["reply"].lower())

print("=" * 78)
print("Sanity — Albanian installment reply, and Albanian delivery AUTO still correct")
rF = post("Porosia #1048 ende s'ka ardhur. Kanë kaluar 6 ditë.")
bF = rF.json()
print(bF["decision"], "|", bF["reply"])
check("caseF (Albanian AUTO) status 200", rF.status_code == 200)
check("caseF decision AUTO", bF["decision"] == "AUTO")
check("caseF no escalation for AUTO", bF["escalation"] is None)
check("caseF reply mentions the 6-day report", "6" in bF["reply"])
# AUTO replies never claimed a handoff before either — confirm still true.
assert_no_handoff_claim("caseF", bF["reply"])

print("\nALL CHECKS PASSED")
