const TEXT = {
  en: {
    workspace: "WORKSPACE", navInbox: "Inbox lab", navEscalations: "Escalations", navAudit: "Audit trail",
    safetyTitle: "Guardrails active", safetyCopy: "Private order details stay protected.", profileName: "Inbox Agent", profileRole: "Demo workspace",
    breadcrumbHome: "Workspace", checking: "Checking API…", apiOnline: "API connected", apiOffline: "API unavailable",
    eyebrow: "AI HACKATHON KOSOVO 2026", title: "Inbox, under control.", subtitle: "Try a customer message and see how the agent handles it—with evidence.", offlineBadge: "Deterministic demo",
    stepOne: "STEP 01", messageHeading: "Choose a test message", messageLabel: "Customer message", messagePlaceholder: "Select an example or type a message…", privacyHint: "Message text is processed, not saved to audit.", processButton: "Process message",
    stepTwo: "STEP 02", resultHeading: "Agent decision", emptyTitle: "Ready when you are", emptyCopy: "Choose a challenge message, then run it to see the real API response.", languageMeta: "LANGUAGE", intentMeta: "INTENT", customerReply: "Customer reply", toolEvidence: "Tool evidence", extractedDetails: "Extracted details",
    trustText: "No model guesses: policy decisions are rule-based, tool calls are visible, sensitive data is protected.", prototypeLabel: "Prototype", escalationEyebrow: "HUMAN REVIEW", escalationTitle: "Escalations", escalationSubtitle: "Requests routed for a teammate to review.", refresh: "Refresh", openHandoffs: "Open handoffs", loading: "Loading…", auditEyebrow: "TRACEABLE DECISIONS", auditTitle: "Audit trail", auditSubtitle: "Inspect a sanitized record by request ID.", requestIdLabel: "Request ID", loadRecord: "Load record", auditEmpty: "Process a message first, then enter its request ID here.", footerNote: "Demo data only · No customer records stored",
    case1: "01 · Delivery delay", case2: "02 · Return request", case3: "03 · Broken product", case4: "04 · Address privacy", case5: "05 · Installments",
    sample1: "Porosia #1048 ende s'ka ardhur. Kanë kaluar 6 ditë.", sample2: "Can I return headphones after 45 days? Box is open.", sample3: "3rd time writing! Laptop broken, NOBODY answers!!", sample4: "Arben's brother here. What's the address on order #1031?", sample5: "A mund ta blej laptopin me këste?",
    processing: "Processing…", apiRequestFailed: "Could not process that message. Check that the backend is running and try again.", escalationCreated: "Human review requested", escalationId: "Escalation", noToolCalls: "No tool calls were needed for this decision.", noEscalations: "No open escalations yet.", auditNotFound: "No audit record found for that request ID.", unknownError: "Something went wrong. Please try again.", details: "Details", toolInput: "INPUT", toolResult: "RESULT", unknownLanguage: "Unknown", noMessage: "Enter or select a message first.", requestFailure: "The backend could not complete this request."
  },
  sq: {
    workspace: "HAPËSIRA E PUNËS", navInbox: "Laboratori i inbox-it", navEscalations: "Përcjelljet", navAudit: "Gjurmët e auditimit",
    safetyTitle: "Mbrojtjet aktive", safetyCopy: "Detajet private të porosive mbrohen.", profileName: "Inbox Agent", profileRole: "Hapësirë demo",
    breadcrumbHome: "Hapësira e punës", checking: "Duke kontrolluar API-n…", apiOnline: "API u lidh", apiOffline: "API nuk është e disponueshme",
    eyebrow: "AI HACKATHON KOSOVO 2026", title: "Inbox-i, nën kontroll.", subtitle: "Provo një mesazh klienti dhe shiko si e trajton agjenti—me prova.", offlineBadge: "Demo deterministe",
    stepOne: "HAPI 01", messageHeading: "Zgjidh një mesazh testues", messageLabel: "Mesazhi i klientit", messagePlaceholder: "Zgjidh një shembull ose shkruaj një mesazh…", privacyHint: "Teksti përpunohet, por nuk ruhet në auditim.", processButton: "Përpuno mesazhin",
    stepTwo: "HAPI 02", resultHeading: "Vendimi i agjentit", emptyTitle: "Gati kur të jesh ti", emptyCopy: "Zgjidh një mesazh të sfidës dhe dërgoje për të parë përgjigjen reale të API-së.", languageMeta: "GJUHA", intentMeta: "QËLLIMI", customerReply: "Përgjigjja për klientin", toolEvidence: "Provat e mjeteve", extractedDetails: "Detajet e nxjerra",
    trustText: "Pa hamendësime të modelit: rregullat përcaktojnë vendimet, thirrjet e mjeteve janë të dukshme dhe të dhënat e ndjeshme mbrohen.", prototypeLabel: "Prototip", escalationEyebrow: "SHQYRTIM NJERËZOR", escalationTitle: "Përcjelljet", escalationSubtitle: "Kërkesa të përcjella për shqyrtim nga ekipi.", refresh: "Rifresko", openHandoffs: "Përcjelljet e hapura", loading: "Duke u ngarkuar…", auditEyebrow: "VENDIME TË GJURMUESHME", auditTitle: "Gjurmët e auditimit", auditSubtitle: "Shiko një regjistrim të pastruar sipas ID-së së kërkesës.", requestIdLabel: "ID e kërkesës", loadRecord: "Ngarko regjistrimin", auditEmpty: "Përpuno fillimisht një mesazh, pastaj shkruaj ID-në e kërkesës këtu.", footerNote: "Vetëm të dhëna demo · Nuk ruhen të dhëna klientësh",
    case1: "01 · Vonesë dërgese", case2: "02 · Kërkesë kthimi", case3: "03 · Produkt i prishur", case4: "04 · Privatësia e adresës", case5: "05 · Pagesa me këste",
    sample1: "Porosia #1048 ende s'ka ardhur. Kanë kaluar 6 ditë.", sample2: "Can I return headphones after 45 days? Box is open.", sample3: "3rd time writing! Laptop broken, NOBODY answers!!", sample4: "Arben's brother here. What's the address on order #1031?", sample5: "A mund ta blej laptopin me këste?",
    processing: "Duke përpunuar…", apiRequestFailed: "Mesazhi nuk u përpunua. Kontrollo nëse backend-i po punon dhe provo sërish.", escalationCreated: "Kërkohet shqyrtim njerëzor", escalationId: "Përcjellja", noToolCalls: "Nuk u nevojitën thirrje mjetesh për këtë vendim.", noEscalations: "Nuk ka përcjellje të hapura.", auditNotFound: "Nuk u gjet regjistrim auditimi për këtë ID.", unknownError: "Ndodhi një gabim. Provo sërish.", details: "Detajet", toolInput: "HYRJA", toolResult: "REZULTATI", unknownLanguage: "E panjohur", noMessage: "Shkruaj ose zgjidh një mesazh fillimisht.", requestFailure: "Backend-i nuk mundi ta përfundojë kërkesën."
  }
};

const CASES = [
  {key:"case1", message:TEXT.en.sample1}, {key:"case2", message:TEXT.en.sample2}, {key:"case3", message:TEXT.en.sample3}, {key:"case4", message:TEXT.en.sample4}, {key:"case5", message:TEXT.en.sample5}
];
let uiLanguage = "en";
let latestRequestId = "";
const $ = (id) => document.getElementById(id);
const t = (key) => TEXT[uiLanguage][key] || TEXT.en[key] || key;

function applyLanguage() {
  document.documentElement.lang = uiLanguage;
  document.querySelectorAll("[data-i18n]").forEach((node) => { node.textContent = t(node.dataset.i18n); });
  document.querySelectorAll("[data-i18n-placeholder]").forEach((node) => { node.placeholder = t(node.dataset.i18nPlaceholder); });
  document.querySelectorAll(".language-button").forEach((button) => {
    const selected = button.dataset.language === uiLanguage;
    button.classList.toggle("is-selected", selected);
    button.setAttribute("aria-pressed", String(selected));
  });
  renderCases();
  updateApiStatus();
}

function renderCases() {
  const list = $("case-list");
  list.replaceChildren();
  CASES.forEach((item, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "case-chip";
    button.textContent = t(item.key);
    button.dataset.caseIndex = String(index);
    button.addEventListener("click", () => {
      $("message-input").value = sampleForUiLanguage(index);
      list.querySelectorAll(".case-chip").forEach((chip) => chip.classList.toggle("is-selected", chip === button));
      $("message-error").hidden = true;
    });
    list.append(button);
  });
}

function sampleForUiLanguage(index) {
  // Preserve official challenge wording in either interface language.
  return uiLanguage === "sq" ? TEXT.sq[`sample${index+1}`] : TEXT.en[`sample${index+1}`];
}

async function updateApiStatus() {
  const status = $("api-status");
  try {
    const response = await fetch("/health", {headers:{"Accept":"application/json"}});
    if (!response.ok) throw new Error("health request failed");
    status.className = "api-status online";
    status.lastElementChild.textContent = t("apiOnline");
  } catch {
    status.className = "api-status offline";
    status.lastElementChild.textContent = t("apiOffline");
  }
}

function showError(element, message) { element.textContent = message; element.hidden = false; }
function clearError(element) { element.textContent = ""; element.hidden = true; }

function pretty(value) { return JSON.stringify(value ?? {}, null, 2); }

function renderResult(data) {
  $("empty-state").hidden = true;
  $("result-content").hidden = false;
  const pill = $("decision-pill");
  pill.textContent = data.decision || "UNKNOWN";
  pill.className = `decision-pill decision-${String(data.decision || "unknown").toLowerCase()}`;
  $("request-id").textContent = data.request_id || "";
  $("result-language").textContent = data.language === "sq" ? "Shqip" : data.language === "en" ? "English" : t("unknownLanguage");
  $("result-intent").textContent = (data.intent || "unknown").replaceAll("_", " ");
  $("result-reply").textContent = data.reply || "";
  latestRequestId = data.request_id || latestRequestId;
  $("audit-id").value = latestRequestId;
  $("escalation-card").hidden = !data.escalation;
  if (data.escalation) {
    $("escalation-card").replaceChildren();
    const strong = document.createElement("strong"); strong.textContent = t("escalationCreated");
    const detail = document.createElement("span"); detail.textContent = `${t("escalationId")}: ${data.escalation.id} · ${data.escalation.status}`;
    $("escalation-card").append(strong, detail);
  }
  const tools = Array.isArray(data.tool_calls) ? data.tool_calls : [];
  $("tool-count").textContent = String(tools.length);
  const list = $("tool-list"); list.replaceChildren();
  if (!tools.length) { const empty = document.createElement("div"); empty.className = "empty-tools"; empty.textContent = t("noToolCalls"); list.append(empty); }
  tools.forEach((call) => {
    const card = document.createElement("div"); card.className = "tool-card";
    const head = document.createElement("div"); head.className = "tool-card-head";
    const name = document.createElement("strong"); name.textContent = call.tool || "tool";
    const tag = document.createElement("span"); tag.className = "tool-tag"; tag.textContent = "RECORDED";
    head.append(name, tag);
    const input = document.createElement("pre"); input.className = "tool-json"; input.textContent = `${t("toolInput")}\n${pretty(call.input)}`;
    const result = document.createElement("pre"); result.className = "tool-json"; result.textContent = `${t("toolResult")}\n${pretty(call.result)}`;
    card.append(head, input, result); list.append(card);
  });
  $("entity-json").textContent = pretty(data.entities);
  refreshEscalationCount();
  if (latestRequestId) loadAudit(latestRequestId, true);
}

async function processMessage() {
  const message = $("message-input").value.trim();
  if (!message) { showError($("message-error"), t("noMessage")); return; }
  clearError($("message-error"));
  const button = $("process-button"); button.disabled = true;
  const label = button.querySelector("span"); const previous = label.textContent; label.textContent = t("processing");
  try {
    const response = await fetch("/api/messages", {method:"POST", headers:{"Content-Type":"application/json","Accept":"application/json"}, body:JSON.stringify({message})});
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || t("requestFailure"));
    renderResult(data);
  } catch (error) {
    showError($("message-error"), error.message || t("apiRequestFailed"));
  } finally { button.disabled = false; label.textContent = previous; }
}

async function refreshEscalationCount() {
  try { const response = await fetch("/api/escalations"); if (!response.ok) return; const records = await response.json(); $("escalation-count").textContent = String(records.length); }
  catch { /* API status already reports connectivity. */ }
}

async function loadEscalations() {
  const list = $("escalations-list"); list.replaceChildren();
  const loading = document.createElement("div"); loading.className = "loading-state"; loading.textContent = t("loading"); list.append(loading);
  try {
    const response = await fetch("/api/escalations");
    if (!response.ok) throw new Error(t("apiRequestFailed"));
    const records = await response.json();
    $("escalations-total").textContent = String(records.length);
    list.replaceChildren();
    if (!records.length) { const empty = document.createElement("div"); empty.className = "loading-state"; empty.textContent = t("noEscalations"); list.append(empty); return; }
    records.forEach((record) => {
      const card = document.createElement("article"); card.className = "record-card";
      const icon = document.createElement("span"); icon.className = "record-icon"; icon.textContent = "↗";
      const main = document.createElement("div"); main.className = "record-main";
      const title = document.createElement("strong"); title.textContent = record.reason || t("escalationCreated");
      const reason = document.createElement("p"); reason.textContent = `${t("requestIdLabel")}: ${record.request_id || "—"}`;
      const id = document.createElement("small"); id.textContent = record.id || "";
      main.append(title, reason, id);
      const badge = document.createElement("span"); badge.className = "record-status"; badge.textContent = record.status || "open";
      card.append(icon, main, badge); list.append(card);
    });
  } catch (error) { list.replaceChildren(); const failure = document.createElement("div"); failure.className = "error-banner"; failure.textContent = error.message || t("unknownError"); list.append(failure); }
}

async function loadAudit(requestId, quiet=false) {
  if (!requestId.trim()) { if (!quiet) showError($("audit-error"), t("auditEmpty")); return; }
  clearError($("audit-error"));
  try {
    const response = await fetch(`/api/audit/${encodeURIComponent(requestId.trim())}`);
    const data = await response.json();
    if (!response.ok) throw new Error(response.status === 404 ? t("auditNotFound") : (data.detail || t("apiRequestFailed")));
    $("audit-record").textContent = pretty(data); $("audit-record").hidden = false; $("audit-empty").hidden = true;
  } catch (error) {
    $("audit-record").hidden = true; $("audit-empty").hidden = true;
    showError($("audit-error"), error.message || t("unknownError"));
  }
}

function showView(name) {
  document.querySelectorAll(".view").forEach((view) => view.classList.toggle("is-visible", view.id === `view-${name}`));
  document.querySelectorAll(".nav-link").forEach((button) => button.classList.toggle("is-active", button.dataset.view === name));
  const titleKey = name === "inbox" ? "navInbox" : name === "audit" ? "navAudit" : "navEscalations";
  $("current-section").textContent = t(titleKey);
  if (name === "escalations") loadEscalations();
}

document.querySelectorAll(".nav-link").forEach((button) => button.addEventListener("click", () => showView(button.dataset.view)));
document.querySelectorAll(".language-button").forEach((button) => button.addEventListener("click", () => { uiLanguage = button.dataset.language; applyLanguage(); }));
$("process-button").addEventListener("click", processMessage);
$("refresh-escalations").addEventListener("click", loadEscalations);
$("load-audit").addEventListener("click", () => loadAudit($("audit-id").value));
$("audit-id").addEventListener("keydown", (event) => { if (event.key === "Enter") loadAudit($("audit-id").value); });
$("message-input").addEventListener("keydown", (event) => { if ((event.ctrlKey || event.metaKey) && event.key === "Enter") processMessage(); });
applyLanguage();
refreshEscalationCount();
