"""Deterministic language, intent, and entity extraction.

This module is intentionally NOT wired into `POST /api/messages` yet.
`extract_message()` is a pure function: given raw text, it returns a
best-effort structured read of that text and nothing else. It never:

- decides policy eligibility, authorization, refunds, or financing terms;
- calls a tool (see app/tools.py) or looks anything up;
- treats a name, order number, or claimed relationship as identity proof;
- fabricates a fact it can't find in the text.

If the message is ambiguous or the intent can't be pinned down
confidently, `intent` stays "unknown" and entities needed for that
intent are left as `None` rather than guessed. Callers should treat a
`None` entity or a listed `missing_or_ambiguous` field as "ask the
customer or route to a human," never as "assume a default."

PHRASE-MATCHING LIMITATIONS (read before extending):
This is regex/keyword matching over two example languages (Albanian and
English), tuned to the five official challenge messages plus two stated
paraphrases. It is NOT a general NLP system:
- Word order, synonyms, or phrasing not seen here can easily fall
  through to `unknown` intent/entities. That is the safe failure mode
  by design, not a bug to "fix" by guessing.
- Albanian diacritic normalization (ë→e, ç→c, etc.) is applied only for
  matching, so keywords need be written in only one diacritic form in
  the pattern tables; the *original* message text is never altered in
  the returned data.
- Number words are matched only for the small set actually needed by
  the five messages (e.g. "3rd", "three", "6 ditë", "45 days"). A
  message using other phrasing for a count may not be extracted.
- Mixed-language or code-switched messages are not specially handled;
  language detection here is a simple keyword/diacritic heuristic, not
  a real language identifier.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Small helpers
# ---------------------------------------------------------------------------

_ALBANIAN_DIACRITIC_MAP = str.maketrans(
    {
        "ë": "e",
        "Ë": "E",
        "ç": "c",
        "Ç": "C",
    }
)


def _normalize_for_matching(text: str) -> str:
    """Lowercase + strip Albanian diacritics, for matching only.

    Never used to alter the text we actually return to callers.
    """
    text = text.translate(_ALBANIAN_DIACRITIC_MAP)
    # Also fold any other combining-mark diacritics defensively.
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return text.lower()


_WORD_NUMBERS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "njё": 1,
    "nje": 1,
    "dy": 2,
    "tre": 3,
    "kater": 4,
    "pese": 5,
}


def _parse_small_number(token: str) -> Optional[int]:
    """Parse "3rd" / "3" / "three" -> 3. Returns None if not recognized."""
    token = token.strip().lower()
    match = re.match(r"^(\d+)(st|nd|rd|th)?$", token)
    if match:
        return int(match.group(1))
    return _WORD_NUMBERS.get(token)


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

_ALBANIAN_MARKERS = [
    "porosia",
    "kane kaluar",
    "kanë kaluar",
    "ditё",
    "dite",
    "ende",
    "s'ka ardhur",
    "ska ardhur",
    "a mund",
    "keste",
    "kёste",
    "blej",
    "laptopin",
    "ime nr",
]

_ENGLISH_MARKERS = [
    "return",
    "headphones",
    "box is open",
    "broken",
    "nobody answers",
    "address",
    "order number",
    "where is it",
    "installment",
]


def _detect_language(normalized_text: str) -> str:
    has_albanian = any(marker in normalized_text for marker in _ALBANIAN_MARKERS)
    has_english = any(marker in normalized_text for marker in _ENGLISH_MARKERS)

    # Albanian-specific characters (before normalization would strip them);
    # check separately on a lightly-cased-only version.
    if has_albanian and not has_english:
        return "sq"
    if has_english and not has_albanian:
        return "en"
    if has_albanian and has_english:
        # Conflicting signals: don't guess which one governs the message.
        return "unknown"
    return "unknown"


# ---------------------------------------------------------------------------
# Entity extraction (independent of intent)
# ---------------------------------------------------------------------------

_ORDER_ID_PATTERNS = [
    r"#\s*(\d{3,6})",
    r"order\s*(?:number|no\.?|nr\.?)?\s*(?:is\s*)?(\d{3,6})",
    r"porosia?\s*(?:ime\s*)?(?:nr\.?)?\s*#?\s*(\d{3,6})",
]


def _extract_order_id(normalized_text: str) -> Optional[str]:
    for pattern in _ORDER_ID_PATTERNS:
        match = re.search(pattern, normalized_text)
        if match:
            return match.group(1)
    return None


_PRODUCT_KEYWORDS = {
    "headphones": "headphones",
    "laptop": "laptop",
    "laptopin": "laptop",  # Albanian accusative form used in message 5
}


def _extract_product(normalized_text: str) -> Optional[str]:
    for keyword, canonical in _PRODUCT_KEYWORDS.items():
        if keyword in normalized_text:
            return canonical
    return None


def _extract_reported_days_elapsed(normalized_text: str) -> Optional[int]:
    """Days phrased as elapsed/waiting time (e.g. delivery delay), not a
    return window. Deliberately kept separate from days_since_purchase.
    """
    match = re.search(r"kaluar\s+(\d+)\s+dit", normalized_text)
    if match:
        return int(match.group(1))
    match = re.search(r"(\d+)\s+dit[eё]", normalized_text)
    if match:
        return int(match.group(1))
    return None


def _extract_days_since_purchase(normalized_text: str) -> Optional[int]:
    """Days phrased in the context of a return (e.g. "after 45 days")."""
    match = re.search(r"after\s+(\d+)\s+day", normalized_text)
    if match:
        return int(match.group(1))
    match = re.search(r"(\d+)\s+days?\s+(?:since|after)", normalized_text)
    if match:
        return int(match.group(1))
    return None


def _extract_package_opened(normalized_text: str) -> Optional[bool]:
    if "box is open" in normalized_text or "package is open" in normalized_text:
        return True
    if "box is unopened" in normalized_text or "unopened" in normalized_text:
        return False
    return None


def _extract_contact_attempts(normalized_text: str) -> Optional[int]:
    match = re.search(r"(\d+)(?:st|nd|rd|th)\s+time\s+writing", normalized_text)
    if match:
        return int(match.group(1))
    match = re.search(r"(\bone|\btwo|\bthree|\bfour|\bfive)\s+time(?:s)?\s+writing", normalized_text)
    if match:
        return _parse_small_number(match.group(1))
    return None


def _extract_unanswered(normalized_text: str) -> Optional[bool]:
    if "nobody answers" in normalized_text or "no one answers" in normalized_text or "unanswered" in normalized_text:
        return True
    return None


def _extract_broken(normalized_text: str) -> Optional[bool]:
    if "broken" in normalized_text or "not working" in normalized_text or "defective" in normalized_text:
        return True
    return None


_RELATIONSHIP_KEYWORDS = [
    "brother",
    "sister",
    "husband",
    "wife",
    "father",
    "mother",
    "friend",
    "relative",
    "vellai",  # "vëllai" (brother) normalized
    "motra",
]


def _extract_relationship_claim(original_text: str, normalized_text: str) -> Optional[str]:
    for keyword in _RELATIONSHIP_KEYWORDS:
        if keyword in normalized_text:
            return keyword if keyword not in ("vellai",) else "brother"
    return None


def _extract_entities(original_text: str, normalized_text: str) -> dict[str, Any]:
    return {
        "order_id": _extract_order_id(normalized_text),
        "product": _extract_product(normalized_text),
        "reported_days_elapsed": _extract_reported_days_elapsed(normalized_text),
        "days_since_purchase": _extract_days_since_purchase(normalized_text),
        "package_opened": _extract_package_opened(normalized_text),
        "contact_attempts": _extract_contact_attempts(normalized_text),
        "unanswered": _extract_unanswered(normalized_text),
        "broken": _extract_broken(normalized_text),
        "relationship_claim": _extract_relationship_claim(original_text, normalized_text),
    }


# ---------------------------------------------------------------------------
# Intent classification
# ---------------------------------------------------------------------------

_INTENTS = (
    "delivery_status",
    "return_request",
    "damaged_product",
    "order_information",
    "installment_purchase",
    "unknown",
)


def _classify_intent(normalized_text: str, entities: dict[str, Any]) -> str:
    """Simple, explicit keyword rules. Returns "unknown" whenever more
    than one intent's signal is present, rather than guessing which one
    the customer meant.
    """
    signals: dict[str, bool] = {
        "delivery_status": bool(
            re.search(r"s'?ka ardhur|ska ardhur|where is it|hasn'?t arrived|not arrived", normalized_text)
        ),
        "return_request": "return" in normalized_text or "kthej" in normalized_text,
        "damaged_product": bool(_extract_broken(normalized_text)) and (
            "writing" in normalized_text or "answers" in normalized_text or "broken" in normalized_text
        ),
        "order_information": bool(
            re.search(r"address|what'?s the address", normalized_text)
        ),
        "installment_purchase": bool(
            re.search(r"keste|installment|instalment|financ", normalized_text)
        ),
    }

    matched = [intent for intent, present in signals.items() if present]

    if len(matched) == 1:
        return matched[0]
    return "unknown"


# ---------------------------------------------------------------------------
# Missing/ambiguous field reporting
# ---------------------------------------------------------------------------

_REQUIRED_ENTITIES_BY_INTENT: dict[str, list[str]] = {
    "delivery_status": ["order_id", "reported_days_elapsed"],
    "return_request": ["product", "days_since_purchase", "package_opened"],
    "damaged_product": ["product", "contact_attempts", "unanswered", "broken"],
    "order_information": ["order_id"],
    "installment_purchase": ["product"],
    "unknown": [],
}


def _find_missing_or_ambiguous(intent: str, entities: dict[str, Any]) -> list[str]:
    required = _REQUIRED_ENTITIES_BY_INTENT.get(intent, [])
    return [field for field in required if entities.get(field) is None]


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def extract_message(message: str, locale: str | None = None) -> dict:
    """Extract language, intent, and entities from a raw customer message.

    `locale` is only ever a hint (e.g. from the request body) — it is
    never allowed to override what the text itself says. This function
    does not call any tool, does not decide eligibility/authorization,
    and does not fabricate a fact that isn't safely inferable from the
    text.
    """
    original_text = message
    normalized_text = _normalize_for_matching(message)

    detected_language = _detect_language(normalized_text)
    # `locale` is a hint only: if detection was confident, trust the text
    # over the hint; if detection was "unknown", a plausible locale hint
    # can be surfaced but is still just a hint, not an override of intent
    # or entity extraction below (which never consult `locale`).
    language = detected_language
    if language == "unknown" and locale in ("sq", "en"):
        language = locale

    entities = _extract_entities(original_text, normalized_text)
    intent = _classify_intent(normalized_text, entities)
    missing_or_ambiguous = _find_missing_or_ambiguous(intent, entities)

    return {
        "language": language,
        "intent": intent,
        "entities": entities,
        "missing_or_ambiguous": missing_or_ambiguous,
    }
