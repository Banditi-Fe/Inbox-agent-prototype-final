"""Deterministic, in-process tool functions for the Inbox Agent.

These are ordinary Python functions — no network or API calls, no
external services, no database. Each returns a plain structured dict.

Scope of this checkpoint (fixtures and tools only): these functions only
retrieve facts or check authorization. They do not decide what a
customer should be told, and they do not choose AUTO/VERIFY/HUMAN/
UNKNOWN — that is the rules/pipeline checkpoint's job, not this one.
"""

from __future__ import annotations

from typing import Any, Callable, Optional

from .data import ORDERS, POLICIES


def lookup_order(order_id: str) -> dict[str, Any]:
    """Look up a fictional demo order by id.

    Never raises for an unknown id or bad input — always returns a
    structured result, with found=False and a safe reason if there is
    no matching record.
    """
    key = str(order_id).strip()
    order = ORDERS.get(key)
    if order is None:
        return {
            "found": False,
            "order_id": key,
            "reason": "order_not_found",
        }
    return {"found": True, **order}


def lookup_policy(policy_key: str) -> dict[str, Any]:
    """Look up a demo policy fact by key.

    Returns an explicit unknown/not-configured result — never a guessed
    or invented policy — for any key that has no verified fixture entry
    (e.g. "financing", or any typo/unknown key).
    """
    key = str(policy_key).strip().lower()
    policy = POLICIES.get(key)
    if policy is None:
        return {
            "found": False,
            "policy_key": key,
            "status": "unknown",
            "reason": "policy_not_configured",
        }
    return {"found": True, **policy}


def verify_customer(
    customer_id: Optional[str],
    order_id: Optional[str],
    verification_data: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Fail-closed identity/authorization check.

    No verification method has been approved for this challenge yet, so
    this always returns verified=False regardless of input. A
    browser-supplied customer_id, an order number, a name, or a claimed
    relationship is never treated as proof of identity.

    Deliberately never returns order or customer private fields (e.g.
    no address) — only whether verification succeeded and why not.
    """
    # Inputs are accepted (and would be used by a real check) but a
    # not-configured method fails closed no matter what was supplied.
    del customer_id, order_id, verification_data
    return {
        "verified": False,
        "reason": "verification_method_not_configured",
    }


class ToolCallRecorder:
    """Collects `{tool, input, result}` evidence for one request.

    Field names ("tool", "input", "result") match `ToolCallRecord` in
    app/schemas.py, so a list of `.calls` can be handed straight to that
    response model once the pipeline checkpoint wires it in.

    Usage:
        recorder = ToolCallRecorder()
        order = recorder.call("lookup_order", {"order_id": "1048"}, lookup_order, "1048")
        recorder.calls  # -> [{"tool": "lookup_order", "input": {...}, "result": {...}}]
    """

    def __init__(self) -> None:
        self._calls: list[dict[str, Any]] = []

    def call(
        self,
        tool_name: str,
        input_data: dict[str, Any],
        fn: Callable[..., dict[str, Any]],
        *args: Any,
        **kwargs: Any,
    ) -> dict[str, Any]:
        result = fn(*args, **kwargs)
        self._calls.append({"tool": tool_name, "input": input_data, "result": result})
        return result

    @property
    def calls(self) -> list[dict[str, Any]]:
        return list(self._calls)
