"""Inbox Agent backend — API and staff interface.

Implements:
- GET  /health
- POST /api/messages          — runs the full pipeline (extraction ->
                                  rules -> escalation -> audit -> reply)
                                  and returns the agreed MessageResponse.
- GET  /api/escalations       — lists in-memory escalation records.
- GET  /api/audit/{request_id} — returns one sanitized audit record, or
                                  404 if the request_id is unknown.

No LLM, no database, no external service. All state (audit records,
escalation records) is in-memory and lives only for the lifetime of
this process, per app/audit.py and app/escalations.py.
"""

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from .audit import get_audit_record
from .escalations import list_escalations
from .pipeline import process_message as run_pipeline
from .reply import generate_reply
from .schemas import EscalationInfo, MessageRequest, MessageResponse, ToolCallRecord

app = FastAPI(
    title="Inbox Agent Backend",
    version="0.2.0",
    description="Backend for the AI Hackathon Kosovo 2026 'Inbox Agent' challenge.",
)


@app.get("/health")
def health() -> dict[str, str]:
    """Basic liveness check."""
    return {"status": "ok"}


@app.post("/api/messages", response_model=MessageResponse)
def create_message(payload: MessageRequest) -> MessageResponse:
    """Run one message through the full pipeline and return the result.

    `customer_id` is only ever a lookup hint (never proof of identity) —
    enforced inside app/rules.py, unchanged here. The reply text is
    generated deterministically from extracted entities and tool-call
    evidence only (app/reply.py) — no LLM, nothing invented.
    """
    summary = run_pipeline(
        payload.message,
        customer_id=payload.customer_id,
        locale=payload.locale,
    )

    # The pipeline just wrote this audit record; it is the source of
    # truth for language/intent/entities/tool_calls in the response, so
    # the response never has to touch the raw message text again.
    audit_record = get_audit_record(summary["request_id"])
    if audit_record is None:  # pragma: no cover — pipeline always writes one
        raise HTTPException(status_code=500, detail="Audit record was not written for this request.")

    reply_text = generate_reply(
        language=audit_record["language"],
        intent=audit_record["intent"],
        decision=summary["decision"],
        entities=audit_record["entities"],
        tool_calls=audit_record["tool_calls"],
    )

    escalation_info = None
    if summary["escalation"] is not None:
        escalation_info = EscalationInfo(
            id=summary["escalation"]["id"],
            reason=summary["escalation"]["reason"],
            status=summary["escalation"]["status"],
        )

    return MessageResponse(
        request_id=summary["request_id"],
        language=audit_record["language"],
        intent=audit_record["intent"],
        entities=audit_record["entities"],
        decision=summary["decision"],
        reply=reply_text,
        tool_calls=[ToolCallRecord(**call) for call in audit_record["tool_calls"]],
        escalation=escalation_info,
    )


@app.get("/api/escalations")
def get_escalations() -> list[dict]:
    """List all in-memory escalation records (open or otherwise)."""
    return list_escalations()


@app.get("/api/audit/{request_id}")
def get_audit(request_id: str) -> dict:
    """Return the sanitized audit record for one request id."""
    record = get_audit_record(request_id)
    if record is None:
        raise HTTPException(status_code=404, detail=f"No audit record found for request_id '{request_id}'.")
    return record


# Serve the staff interface from the same origin as the API so the browser
# can call these routes without a separate frontend server or CORS setup.
_frontend_dir = Path(__file__).resolve().parents[2] / "frontend"
app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")
