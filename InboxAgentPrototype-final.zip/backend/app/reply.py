"""Deterministic, template-based customer-facing reply text.

No LLM, no free-generation: every reply is built only from the already
sanitized `entities` and `tool_calls` produced by the pipeline
(app/extraction.py + app/rules.py, via app/pipeline.py) — never from the
raw message text (this module never even receives it). Nothing here
invents a policy, a fact, a promise, or a private value.

Replies are produced in the detected language when it is "sq" or "en";
any other value (including "unknown") falls back to English, since only
those two are supported at this checkpoint.

HANDOFF WORDING RULE (checkpoint 7 fix): `app/pipeline.py` creates an
escalation record if and only if `decision == "HUMAN"`. Every reply
template in this file must only claim a team handoff, forwarding, or
"someone will review this" when `decision == "HUMAN"` — because that is
the only case where such a record actually exists. For every other
decision (in practice, "UNKNOWN" for every branch below where this
matters — "AUTO" and "VERIFY" already have their own non-handoff
wording), the reply instead says the system cannot safely answer from
the available information and directs the customer to contact the shop
directly. It never claims a forward or review that did not happen.
"""

from __future__ import annotations

from typing import Any, Optional

_CONTACT_SHOP_SQ = "Ju lutemi kontaktoni dyqanin drejtpërdrejt"
_CONTACT_SHOP_EN = "Please contact the shop directly"


def _tool_result(tool_calls: list[dict[str, Any]], tool_name: str) -> dict[str, Any]:
    for call in tool_calls:
        if call.get("tool") == tool_name:
            return call.get("result") or {}
    return {}


def generate_reply(
    *,
    language: Optional[str],
    intent: Optional[str],
    decision: str,
    entities: dict[str, Any],
    tool_calls: list[dict[str, Any]],
) -> str:
    lang = language if language in ("sq", "en") else "en"

    if intent == "delivery_status":
        return _reply_delivery_status(lang, decision, entities, tool_calls)
    if intent == "return_request":
        return _reply_return_request(lang, decision, entities, tool_calls)
    if intent == "damaged_product":
        return _reply_damaged_product(lang, decision, entities)
    if intent == "order_information":
        return _reply_order_information(lang, decision, entities)
    if intent == "installment_purchase":
        return _reply_installment_purchase(lang, decision, entities)

    return _reply_fallback(lang, decision)


def _reply_delivery_status(lang: str, decision: str, entities: dict[str, Any], tool_calls: list[dict[str, Any]]) -> str:
    order_result = _tool_result(tool_calls, "lookup_order")
    policy_result = _tool_result(tool_calls, "lookup_policy")
    order_id = entities.get("order_id")
    # Kept exactly as extracted — never relabeled as "working days".
    reported_days = entities.get("reported_days_elapsed")
    status = order_result.get("status")

    window = None
    if policy_result.get("found") and "window_days_min" in policy_result:
        window = f"{policy_result['window_days_min']}-{policy_result['window_days_max']} {policy_result['unit']}"

    if decision == "AUTO" and status == "delayed":
        if lang == "sq":
            msg = f"Porosia #{order_id} është shënuar si e vonuar në sistemin tonë."
            if reported_days is not None:
                msg += f" Ju keni raportuar {reported_days} ditë të kaluara që nga porosia."
            if window:
                msg += f" Afati ynë standard i dërgesës është {window}."
            return msg
        msg = f"Order #{order_id} is marked as delayed in our records."
        if reported_days is not None:
            msg += f" You reported {reported_days} day(s) elapsed so far."
        if window:
            msg += f" Our standard delivery window is {window}."
        return msg

    # UNKNOWN (order not confirmed delayed / not found): no escalation is
    # created for this decision, so do not claim one was forwarded or
    # will be reviewed by a team member.
    if lang == "sq":
        return (
            f"Nuk mund ta konfirmojmë me siguri statusin e porosisë #{order_id} me informacionin që kemi "
            f"në dispozicion. {_CONTACT_SHOP_SQ} për një përditësim."
        )
    return (
        f"We can't confirm order #{order_id}'s exact delivery status from the information available to us. "
        f"{_CONTACT_SHOP_EN} for an update."
    )


def _reply_return_request(lang: str, decision: str, entities: dict[str, Any], tool_calls: list[dict[str, Any]]) -> str:
    policy_result = _tool_result(tool_calls, "lookup_policy")
    days = entities.get("days_since_purchase")
    opened = entities.get("package_opened")
    product = entities.get("product") or ("artikulli" if lang == "sq" else "item")
    window_days = policy_result.get("window_days")
    condition = policy_result.get("condition")

    if decision == "AUTO":
        if lang == "sq":
            return f"Kërkesa juaj për kthimin e {product} është brenda politikës standarde ({window_days} ditë, {condition})."
        return f"Your return request for the {product} is within our standard policy ({window_days} days, {condition})."

    if decision == "HUMAN":
        # An escalation record is always created for this decision — the
        # "forwarded for review" claim is accurate here.
        if lang == "sq":
            return (
                f"Kërkesa juaj për kthimin e {product} pas {days} ditësh "
                f"({'kutia e hapur' if opened else 'kutia e mbyllur'}) del jashtë politikës sonë "
                f"standarde të kthimit ({window_days} ditë, vetëm {condition}). Nuk mund të premtojmë "
                "një përjashtim apo rimbursim automatikisht; kjo po i kalohet një përfaqësuesi për shqyrtim."
            )
        return (
            f"Your return request for the {product} after {days} day(s) "
            f"({'box opened' if opened else 'box unopened'}) falls outside our standard return policy "
            f"({window_days} days, {condition} only). We can't promise an exception or refund "
            "automatically — this has been forwarded to a team member for review."
        )

    # UNKNOWN (missing days_since_purchase / package_opened / no policy):
    # no escalation exists for this decision — don't claim one.
    if lang == "sq":
        return (
            f"Na mungon informacion për të vlerësuar kërkesën tuaj për kthimin e {product}. "
            f"{_CONTACT_SHOP_SQ} me këto detaje."
        )
    return (
        f"We don't have enough information to evaluate your return request for the {product} from what's "
        f"available to us. {_CONTACT_SHOP_EN} with these details."
    )


def _reply_damaged_product(lang: str, decision: str, entities: dict[str, Any]) -> str:
    product = entities.get("product") or ("produkti" if lang == "sq" else "product")

    if decision == "HUMAN":
        # app/rules.py always returns HUMAN for this intent, so an
        # escalation always exists — the "escalated" claim is accurate.
        if lang == "sq":
            return (
                f"Na vjen keq për problemin e vazhdueshëm me {product} tuaj. E kemi përcjellë këtë çështje "
                "tek një përfaqësues për shqyrtim urgjent; nuk është zgjidhur ende automatikisht."
            )
        return (
            f"We're sorry about the ongoing issue with your {product}. This has been escalated to a team "
            "member for urgent review; it has not been resolved automatically."
        )

    # Defensive fallback: no branch in app/rules.py currently returns a
    # non-HUMAN decision for this intent, but if that ever changes, this
    # must not claim a handoff that doesn't exist.
    if lang == "sq":
        return (
            f"Nuk mund ta trajtojmë me siguri çështjen me {product} tuaj me informacionin që kemi. "
            f"{_CONTACT_SHOP_SQ} për ndihmë."
        )
    return (
        f"We can't safely handle the issue with your {product} from the information available to us. "
        f"{_CONTACT_SHOP_EN} for help."
    )


def _reply_order_information(lang: str, decision: str, entities: dict[str, Any]) -> str:
    order_id = entities.get("order_id")
    # Deliberately never includes the order's address or any other
    # private field — only mentions the *category* "address" as an
    # example of what needs verification, never the value itself.
    if decision == "VERIFY":
        if lang == "sq":
            return (
                f"Për arsye sigurie, nuk mund të ndajmë detaje private të porosisë #{order_id} "
                "(si adresa e dërgesës) pa verifikuar më parë identitetin tuaj përmes një metode "
                "të aprovuar. Ju lutemi na kontaktoni për të filluar verifikimin."
            )
        return (
            f"For security reasons, we can't share private details of order #{order_id} (such as the "
            "delivery address) without first verifying your identity through an approved method. "
            "Please reach out so we can start verification."
        )

    # UNKNOWN (no order id extracted) or the currently-unreachable AUTO
    # branch: neither claims a team handoff, which is already correct
    # (no escalation exists for either), so only the wording is tightened
    # to explicitly direct the customer to contact the shop.
    if lang == "sq":
        return (
            f"Nuk mund ta përpunojmë këtë kërkesë me informacionin që kemi në dispozicion. "
            f"{_CONTACT_SHOP_SQ} me numrin e porosisë tuaj."
        )
    return (
        f"We can't process this request from the information available to us. "
        f"{_CONTACT_SHOP_EN} with your order number."
    )


def _reply_installment_purchase(lang: str, decision: str, entities: dict[str, Any]) -> str:
    product = entities.get("product") or ("produkti" if lang == "sq" else "the product")

    if decision == "HUMAN":
        # Defensive: app/rules.py always returns UNKNOWN for this intent
        # today, but if that ever changes, only claim a handoff when one
        # actually exists.
        if lang == "sq":
            return (
                f"Aktualisht nuk kemi një politikë të konfirmuar financimi/me këste për {product}. "
                "Kjo po i kalohet një përfaqësuesi për shqyrtim."
            )
        return (
            f"We don't currently have a confirmed installment/financing policy for {product}. "
            "This has been forwarded to a team member for review."
        )

    # UNKNOWN (the actual, only outcome today): no escalation is created
    # for this decision, so do not say the question is being forwarded
    # or that someone will get back to them.
    if lang == "sq":
        return (
            f"Aktualisht nuk kemi një politikë të konfirmuar financimi/me këste për {product}, kështu që "
            f"nuk mund t'i përgjigjemi kësaj në mënyrë të sigurt me informacionin që kemi. {_CONTACT_SHOP_SQ} "
            "për opsionet e financimit."
        )
    return (
        f"We don't currently have a confirmed installment/financing policy for {product}, so we can't "
        f"safely answer this from the information available to us. {_CONTACT_SHOP_EN} for financing options."
    )


def _reply_fallback(lang: str, decision: str) -> str:
    if decision == "HUMAN":
        # Defensive: the catch-all rule in app/rules.py always returns
        # UNKNOWN for an unclassified intent today, but if that ever
        # changes, only claim a handoff when one actually exists.
        if lang == "sq":
            return "Nuk arritëm ta kuptojmë plotësisht kërkesën tuaj. Kjo po i kalohet dikujt nga ekipi ynë."
        return "We couldn't fully understand your request. This has been forwarded to someone on our team."

    # UNKNOWN (the actual, only outcome today): no escalation exists, so
    # do not claim someone from the team will look at it.
    if lang == "sq":
        return (
            f"Nuk arritëm ta kuptojmë plotësisht kërkesën tuaj dhe nuk mund t'i përgjigjemi në mënyrë të "
            f"sigurt me informacionin që kemi. {_CONTACT_SHOP_SQ} për ndihmë."
        )
    return (
        f"We couldn't fully understand your request and can't safely answer it from the information "
        f"available to us. {_CONTACT_SHOP_EN} for help."
    )
