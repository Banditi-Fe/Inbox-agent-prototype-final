"""In-memory, process-lifetime human-escalation records.

Corresponds to the "escalations" module in the architecture doc:
append-only records with a reason, case/request id, and status. Storage
lives only for as long as this process runs — no database, no file, no
external service.

Never store the raw customer message text or any private order field
(e.g. address) here — callers must pass an already-sanitized reason.
"""

from __future__ import annotations

import itertools
from typing import Any, Optional

_escalations: dict[str, dict[str, Any]] = {}
_id_counter = itertools.count(1)


def create_escalation(reason: str, request_id: str) -> dict[str, Any]:
    """Create and store a new open escalation record.

    `reason` should already be a short, sanitized explanation (e.g. the
    rule's own `reason` string) — never the raw message text.
    Returns a copy of the stored record.
    """
    escalation_id = f"esc-{next(_id_counter):06d}"
    record: dict[str, Any] = {
        "id": escalation_id,
        "reason": reason,
        "request_id": request_id,
        "status": "open",
    }
    _escalations[escalation_id] = record
    return dict(record)


def get_escalation(escalation_id: str) -> Optional[dict[str, Any]]:
    """Look up a stored escalation record, or None if it doesn't exist."""
    record = _escalations.get(escalation_id)
    return dict(record) if record is not None else None


def list_escalations() -> list[dict[str, Any]]:
    """Return copies of all stored escalation records."""
    return [dict(record) for record in _escalations.values()]


def _reset_for_tests() -> None:
    """Test-only helper: clear stored state and restart id numbering.

    Not used by any production code path — only by the verification
    script, so repeated runs don't accumulate state or shift ids.
    """
    _escalations.clear()
    global _id_counter
    _id_counter = itertools.count(1)
