"""In-memory, process-lifetime sanitized audit records.

Corresponds to the "audit" module in the architecture doc: one
structured record per processed request, containing request id,
language, intent, entities, tool-call evidence, decision, and an
escalation id if one was created. Storage lives only for the lifetime
of this process — no database, no file, no external service.

Never store the raw customer message text or any private order field
(e.g. address) here — callers are responsible for passing already-safe
entities/tool_calls (see app/pipeline.py, which sanitizes tool-call
results before calling write_audit_record()).
"""

from __future__ import annotations

import itertools
from typing import Any, Optional

_audit_records: dict[str, dict[str, Any]] = {}
_id_counter = itertools.count(1)


def next_request_id() -> str:
    """Generate the next request id. Called once per processed message."""
    return f"req-{next(_id_counter):06d}"


def write_audit_record(
    *,
    request_id: str,
    language: Optional[str],
    intent: Optional[str],
    entities: dict[str, Any],
    tool_calls: list[dict[str, Any]],
    decision: str,
    escalation_id: Optional[str],
) -> dict[str, Any]:
    """Store exactly one sanitized audit record for a processed request.

    Deliberately has no `message` / `raw_text` parameter at all — there
    is nowhere for raw customer text to go even by mistake.
    """
    record: dict[str, Any] = {
        "request_id": request_id,
        "language": language,
        "intent": intent,
        "entities": entities,
        "tool_calls": tool_calls,
        "decision": decision,
        "escalation_id": escalation_id,
    }
    _audit_records[request_id] = record
    return dict(record)


def get_audit_record(request_id: str) -> Optional[dict[str, Any]]:
    """Look up a stored audit record, or None if it doesn't exist."""
    record = _audit_records.get(request_id)
    return dict(record) if record is not None else None


def list_audit_records() -> list[dict[str, Any]]:
    """Return copies of all stored audit records."""
    return [dict(record) for record in _audit_records.values()]


def _reset_for_tests() -> None:
    """Test-only helper: clear stored state and restart id numbering.

    Not used by any production code path — only by the verification
    script, so repeated runs don't accumulate state or shift ids.
    """
    _audit_records.clear()
    global _id_counter
    _id_counter = itertools.count(1)
