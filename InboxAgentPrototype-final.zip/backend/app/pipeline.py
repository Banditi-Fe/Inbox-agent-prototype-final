"""Orchestration: extraction -> rules -> escalation -> audit.

Corresponds to the "agent" module in the architecture doc (pipeline
orchestration). `process_message()` is the one small function this
checkpoint adds:

    process_message(message, customer_id=None, locale=None, verification_data=None) -> dict

It calls `extract_message()` (app/extraction.py, unmodified), then
`evaluate()` (app/rules.py, unmodified), then:
  - creates an escalation record only when the decision is HUMAN
    (app/escalations.py);
  - writes exactly one sanitized audit record for every request
    (app/audit.py);
and returns a small summary.

NOT wired into any FastAPI route yet — `POST /api/messages` still
returns 501. This function is only called directly (see the
verification script) at this checkpoint. It still does not generate
customer-facing reply text or call an LLM.

PRIVACY: the raw `message` text is used only in-memory, for this one
call, to extract structured facts — it is never passed to
create_escalation() or write_audit_record(), and neither of those
functions even accepts a raw-text parameter. Tool-call evidence coming
back from rules.evaluate() is additionally re-sanitized here (see
_sanitize_tool_calls) before being stored, as defense in depth on top of
what app/rules.py already redacts for the #1031-style case.
"""

from __future__ import annotations

from typing import Any, Optional

from .audit import next_request_id, write_audit_record
from .escalations import create_escalation
from .extraction import extract_message
from .rules import evaluate

# Fields that must never be persisted in stored tool-call evidence, even
# if a tool's raw result happened to include them. `lookup_order`'s raw
# result can include these for order #1031 (address) — app/rules.py
# already redacts that specific case, but this list is applied to every
# tool call as a second, independent safety net rather than relying on
# each rule to always remember to redact correctly.
_PRIVATE_ORDER_FIELDS = {"address", "customer_id", "notes", "is_mock"}


def _sanitize_tool_call(call: dict[str, Any]) -> dict[str, Any]:
    tool_name = call.get("tool")
    raw_result = call.get("result") or {}
    if tool_name == "lookup_order":
        safe_result = {k: v for k, v in raw_result.items() if k not in _PRIVATE_ORDER_FIELDS}
    else:
        # lookup_policy results are just policy numbers (not private);
        # verify_customer already never returns order/customer fields.
        safe_result = dict(raw_result)
    return {
        "tool": tool_name,
        "input": dict(call.get("input") or {}),
        "result": safe_result,
    }


def _sanitize_tool_calls(calls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [_sanitize_tool_call(call) for call in calls]


def process_message(
    message: str,
    *,
    customer_id: Optional[str] = None,
    locale: Optional[str] = None,
    verification_data: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Run one message through extraction, rules, escalation, and audit.

    Returns:
        {
          "request_id": str,
          "decision": "AUTO" | "VERIFY" | "HUMAN" | "UNKNOWN",
          "reason": str,
          "escalation": {"id", "reason", "request_id", "status"} | None,
        }

    Guarantees:
    - Exactly one audit record is written per call.
    - An escalation record is created if and only if decision == "HUMAN".
    - The raw `message` text is never stored anywhere.
    - No order address or other private order field is stored in the
      audit record's tool-call evidence.
    """
    request_id = next_request_id()

    extraction = extract_message(message, locale)
    decision_obj = evaluate(
        extraction,
        customer_id=customer_id,
        verification_data=verification_data,
    )

    safe_tool_calls = _sanitize_tool_calls(decision_obj["tool_calls"])

    escalation: Optional[dict[str, Any]] = None
    if decision_obj["decision"] == "HUMAN":
        escalation = create_escalation(reason=decision_obj["reason"], request_id=request_id)

    write_audit_record(
        request_id=request_id,
        language=extraction.get("language"),
        intent=extraction.get("intent"),
        entities=extraction.get("entities", {}),
        tool_calls=safe_tool_calls,
        decision=decision_obj["decision"],
        escalation_id=escalation["id"] if escalation else None,
    )

    return {
        "request_id": request_id,
        "decision": decision_obj["decision"],
        "reason": decision_obj["reason"],
        "escalation": escalation,
    }
