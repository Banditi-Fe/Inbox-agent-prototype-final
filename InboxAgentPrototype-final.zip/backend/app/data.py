"""Fictional, in-memory demo fixtures for the Inbox Agent.

PROVENANCE NOTE (read before editing):
No `work/backend-architecture.md` or challenge-brief file exists in this
repository/container — this was checked directly before writing this
file. The two policy facts below (delivery window, unopened-return
window) were supplied as explicit instructions in the checkpoint-2
prompt text itself, not read from a brief document. They are recorded
here as the policy values to use, but they are only as verified as that
prompt text — if an actual official brief later contradicts them,
update this file and say so in the README/audit trail. Everything else
(order statuses, addresses, customer ids, financing) is either an
obvious placeholder or an explicit "not configured" result — never a
real-looking invented fact.

All data below is fictional and for demo/hackathon purposes only.
"""

from typing import Any

# ---------------------------------------------------------------------------
# Orders
#
# Only the two order ids named in the challenge scenarios are seeded:
#   #1048 — delayed-order scenario
#   #1031 — unauthorized address-request scenario
#
# Every field is either a mock/placeholder value (labeled) or omitted.
# ---------------------------------------------------------------------------

ORDERS: dict[str, dict[str, Any]] = {
    "1048": {
        "order_id": "1048",
        "customer_id": "cust-demo-01",  # ASSUMPTION: fictional linkage for the demo only.
        "status": "delayed",  # ASSUMPTION: mock status, not confirmed against a real system.
        "days_late": 6,  # From the challenge message text ("six days"). NOTE: the message
        # says six days, not six *working* days — do not silently convert
        # this into the delivery policy's "working days" unit below.
        "product": None,  # Not specified anywhere verified; left unknown rather than guessed.
        "is_mock": True,
        "notes": (
            "MOCK/DEMO order record for hackathon fixture purposes only. "
            "days_late is taken verbatim from the challenge message wording."
        ),
    },
    "1031": {
        "order_id": "1031",
        "customer_id": "cust-demo-02",  # ASSUMPTION: fictional linkage for the demo only.
        "status": "processing",  # ASSUMPTION: mock status, not confirmed against a real system.
        "address": "Rruga Demo Nr. 12, Prishtinë — FICTIONAL PLACEHOLDER ADDRESS, not a real location",
        "product": None,
        "is_mock": True,
        "notes": (
            "MOCK/DEMO order record. The address field exists only to exercise the "
            "later authorization/disclosure rule (checkpoint 4); it is obviously "
            "fictional and must never be returned by verify_customer."
        ),
    },
}


# ---------------------------------------------------------------------------
# Policies
#
# "delivery" and "returns" are recorded as provided in the checkpoint-2
# prompt text (see provenance note above). "financing" is deliberately
# absent — lookup_policy() returns an explicit not-configured result for
# it and for any other unseeded key, rather than inventing terms.
# ---------------------------------------------------------------------------

POLICIES: dict[str, dict[str, Any]] = {
    "delivery": {
        "policy_key": "delivery",
        "summary": "Standard delivery window",
        "window_days_min": 2,
        "window_days_max": 4,
        "unit": "working days",
        "source": "provided_in_task_prompt",  # see provenance note above — not read from a repo file
    },
    "returns": {
        "policy_key": "returns",
        "summary": "Return window for unopened items",
        "window_days": 30,
        "condition": "unopened",
        "source": "provided_in_task_prompt",
        "notes": (
            "Only covers unopened items within 30 days. Says nothing about "
            "opened-box returns or returns after 30 days — do not infer an "
            "outcome for those cases from this record."
        ),
    },
    # "financing" intentionally not present: lookup_policy() will return
    # found=False / status="unknown" / reason="policy_not_configured".
}
