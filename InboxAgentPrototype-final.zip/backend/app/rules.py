"""Deterministic authorization and rule evaluation.

Consumes the output of `app.extraction.extract_message()` and calls the
existing tool functions in `app.tools` (which read fixtures from
`app.data`). Produces a small structured decision result: one of
`AUTO` / `VERIFY` / `HUMAN` / `UNKNOWN`, a short reason, and only facts
that came from a fixture lookup — never invented policy or private data.

Explicitly OUT OF SCOPE for this checkpoint (see individual rule
functions for how each is handled instead):
- generating the actual customer-facing reply text;
- storing an escalation record;
- writing an audit log;
- any LLM call;
- wiring any of this into the FastAPI routes (`POST /api/messages`
  still returns 501 — this module is only used directly for now).

Nothing here modifies `app/extraction.py`, `app/tools.py`, or
`app/data.py` — it only imports and calls them.
"""

from __future__ import annotations

from typing import Any, Optional

from .tools import ToolCallRecorder, lookup_order, lookup_policy, verify_customer

# The four decision values used throughout. Kept as a plain tuple (not a
# new Pydantic model) since app/schemas.py already defines the wire
# contract and this checkpoint deliberately isn't wired into it yet.
DECISIONS = ("AUTO", "VERIFY", "HUMAN", "UNKNOWN")


def _decision(
    decision: str,
    reason: str,
    facts: dict[str, Any],
    tool_calls: list[dict[str, Any]],
    missing_facts: Optional[list[str]] = None,
) -> dict[str, Any]:
    assert decision in DECISIONS, f"invalid decision: {decision!r}"
    return {
        "decision": decision,
        "reason": reason,
        "facts": facts,
        "tool_calls": tool_calls,
        "missing_facts": missing_facts or [],
    }


# ---------------------------------------------------------------------------
# Case 1 — delivery status (#1048 style messages)
# ---------------------------------------------------------------------------


def _rule_delivery_status(entities: dict[str, Any], recorder: ToolCallRecorder) -> dict[str, Any]:
    order_id = entities.get("order_id")
    reported_days_elapsed = entities.get("reported_days_elapsed")

    if not order_id:
        return _decision(
            "UNKNOWN",
            "No order id was extracted from the message; cannot look up a delivery status.",
            facts={},
            tool_calls=recorder.calls,
            missing_facts=["order_id"],
        )

    order = recorder.call("lookup_order", {"order_id": order_id}, lookup_order, order_id)

    if not order.get("found"):
        return _decision(
            "UNKNOWN",
            f"No order record was found for #{order_id}.",
            facts={"order_id": order_id},
            tool_calls=recorder.calls,
            missing_facts=["order_record"],
        )

    delivery_policy = recorder.call("lookup_policy", {"policy_key": "delivery"}, lookup_policy, "delivery")

    facts: dict[str, Any] = {
        "order_id": order_id,
        "order_status": order.get("status"),
        # Kept verbatim as the customer's own reported elapsed days.
        # Deliberately NOT relabeled or converted into the delivery
        # policy's "working days" unit below — those are different units
        # from different sources.
        "customer_reported_days_elapsed": reported_days_elapsed,
    }
    if delivery_policy.get("found"):
        facts["standard_delivery_window"] = {
            "min": delivery_policy["window_days_min"],
            "max": delivery_policy["window_days_max"],
            "unit": delivery_policy["unit"],
        }

    if order.get("status") == "delayed":
        # The retrieved order record itself explicitly says "delayed" —
        # that is the fixture-supported fact being reported, not a
        # conclusion computed from the customer's day count.
        return _decision(
            "AUTO",
            "Retrieved order record explicitly marks this order as delayed; "
            "reporting that status only, without recomputing lateness from "
            "the customer's reported day count.",
            facts=facts,
            tool_calls=recorder.calls,
        )

    return _decision(
        "UNKNOWN",
        "Retrieved order record does not explicitly confirm a delay; "
        "cannot label the order overdue without guessing.",
        facts=facts,
        tool_calls=recorder.calls,
        missing_facts=["order_delay_confirmation"],
    )


# ---------------------------------------------------------------------------
# Case 2 — return request (opened box, 45 days)
# ---------------------------------------------------------------------------


def _rule_return_request(entities: dict[str, Any], recorder: ToolCallRecorder) -> dict[str, Any]:
    days_since_purchase = entities.get("days_since_purchase")
    package_opened = entities.get("package_opened")
    product = entities.get("product")

    return_policy = recorder.call("lookup_policy", {"policy_key": "returns"}, lookup_policy, "returns")

    if not return_policy.get("found"):
        return _decision(
            "UNKNOWN",
            "No return policy is configured; cannot evaluate this request.",
            facts={"product": product},
            tool_calls=recorder.calls,
            missing_facts=["return_policy"],
        )

    facts: dict[str, Any] = {
        "product": product,
        "days_since_purchase": days_since_purchase,
        "package_opened": package_opened,
        "policy_window_days": return_policy["window_days"],
        "policy_condition": return_policy["condition"],
    }

    missing = [
        field
        for field, value in (
            ("days_since_purchase", days_since_purchase),
            ("package_opened", package_opened),
        )
        if value is None
    ]
    if missing:
        return _decision(
            "UNKNOWN",
            "Missing facts needed to evaluate the return policy.",
            facts=facts,
            tool_calls=recorder.calls,
            missing_facts=missing,
        )

    within_window = days_since_purchase <= return_policy["window_days"]
    meets_condition = package_opened is False  # policy condition is "unopened"

    if within_window and meets_condition:
        return _decision(
            "AUTO",
            f"Within the {return_policy['window_days']}-day unopened return window.",
            facts=facts,
            tool_calls=recorder.calls,
        )

    violation_reasons = []
    if not within_window:
        violation_reasons.append(
            f"{days_since_purchase} days since purchase exceeds the {return_policy['window_days']}-day window"
        )
    if not meets_condition:
        violation_reasons.append("package is opened, and the policy only covers unopened items")

    facts["outside_standard_policy"] = True
    facts["outside_standard_policy_reasons"] = violation_reasons

    # The architecture's own decision definitions list "exception" as a
    # HUMAN trigger. A return that falls outside the stated policy is,
    # by definition, a request for an exception to that policy — so this
    # routes to HUMAN rather than being auto-approved or auto-rejected.
    # No exception or refund is promised here.
    return _decision(
        "HUMAN",
        "Request is outside the standard return policy (" + "; ".join(violation_reasons) + "); "
        "routing to a human rather than promising an exception or refund.",
        facts=facts,
        tool_calls=recorder.calls,
    )


# ---------------------------------------------------------------------------
# Case 3 — repeated broken-product complaint
# ---------------------------------------------------------------------------


def _rule_damaged_product(entities: dict[str, Any], recorder: ToolCallRecorder) -> dict[str, Any]:
    facts = {
        "product": entities.get("product"),
        "contact_attempts": entities.get("contact_attempts"),
        "unanswered": entities.get("unanswered"),
        "broken": entities.get("broken"),
    }
    # No order id is present in this message and no policy determines an
    # outcome here — a repeated, unanswered complaint about a broken
    # product is a mandatory human-review case regardless of what a
    # policy fixture might say. Never claim it was resolved.
    return _decision(
        "HUMAN",
        "Repeated complaint about a broken, unresolved product issue; requires human review. Not auto-resolved.",
        facts=facts,
        tool_calls=recorder.calls,
    )


# ---------------------------------------------------------------------------
# Case 4 — order information / address request (#1031 style messages)
# ---------------------------------------------------------------------------


def _rule_order_information(
    entities: dict[str, Any],
    recorder: ToolCallRecorder,
    customer_id: Optional[str],
    verification_data: Optional[dict[str, Any]],
) -> dict[str, Any]:
    order_id = entities.get("order_id")
    relationship_claim = entities.get("relationship_claim")

    facts: dict[str, Any] = {
        "order_id": order_id,
        # Record only that a relationship claim was present, never treat
        # it (or the order id, or any name) as identity proof.
        "relationship_claim_present": relationship_claim is not None,
    }

    if not order_id:
        return _decision(
            "UNKNOWN",
            "No order id was extracted; cannot evaluate an order-information request.",
            facts=facts,
            tool_calls=recorder.calls,
            missing_facts=["order_id"],
        )

    # Call lookup_order directly (NOT through the recorder) because its
    # raw result includes the order's private fields (e.g. address).
    # A redacted summary is appended to the returned tool_calls list
    # instead — the full order record, address included, must never
    # appear there. (tools.py is left unmodified; the redaction happens
    # here, in the caller, rather than by adding a new recorder method.)
    order = lookup_order(order_id)
    order_found = order.get("found", False)
    redacted_order_result: dict[str, Any] = {"found": order_found}
    if not order_found:
        redacted_order_result["reason"] = order.get("reason")
    order_lookup_evidence = {
        "tool": "lookup_order",
        "input": {"order_id": order_id},
        "result": redacted_order_result,
    }
    facts["order_found"] = order_found

    verification = recorder.call(
        "verify_customer",
        {"customer_id": customer_id, "order_id": order_id, "verification_data": verification_data},
        verify_customer,
        customer_id,
        order_id,
        verification_data,
    )
    facts["verified"] = verification.get("verified", False)
    facts["verification_reason"] = verification.get("reason")

    if verification.get("verified") is True:
        # No approved verification method exists in this codebase today,
        # so this branch is unreachable in practice — kept explicit for
        # if/when a real verification method is added.
        return _decision(
            "AUTO",
            "Identity verified via an approved method; disclosure may proceed "
            "(actual disclosure logic is not implemented at this checkpoint).",
            facts=facts,
            tool_calls=[order_lookup_evidence] + recorder.calls,
        )

    return _decision(
        "VERIFY",
        "Requester identity is not verified — a name, order number, or claimed "
        "relationship is never treated as proof of identity. Failing closed and "
        "requesting verification before any disclosure.",
        facts=facts,
        tool_calls=[order_lookup_evidence] + recorder.calls,
    )


# ---------------------------------------------------------------------------
# Case 5 — installment / financing question
# ---------------------------------------------------------------------------


def _rule_installment_purchase(entities: dict[str, Any], recorder: ToolCallRecorder) -> dict[str, Any]:
    financing_policy = recorder.call("lookup_policy", {"policy_key": "financing"}, lookup_policy, "financing")
    facts = {
        "product": entities.get("product"),
        "financing_policy_found": financing_policy.get("found", False),
    }
    return _decision(
        "UNKNOWN",
        "No financing/installment policy is configured; terms are unspecified and must not be invented.",
        facts=facts,
        tool_calls=recorder.calls,
        missing_facts=["financing_policy"],
    )


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

_INTENT_RULES = {
    "delivery_status": lambda entities, recorder, customer_id, verification_data: _rule_delivery_status(
        entities, recorder
    ),
    "return_request": lambda entities, recorder, customer_id, verification_data: _rule_return_request(
        entities, recorder
    ),
    "damaged_product": lambda entities, recorder, customer_id, verification_data: _rule_damaged_product(
        entities, recorder
    ),
    "order_information": lambda entities, recorder, customer_id, verification_data: _rule_order_information(
        entities, recorder, customer_id, verification_data
    ),
    "installment_purchase": lambda entities, recorder, customer_id, verification_data: _rule_installment_purchase(
        entities, recorder
    ),
}


def evaluate(
    extraction: dict[str, Any],
    *,
    customer_id: Optional[str] = None,
    verification_data: Optional[dict[str, Any]] = None,
) -> dict[str, Any]:
    """Evaluate an already-extracted message and return a decision.

    `extraction` is the dict returned by `app.extraction.extract_message()`
    — this function does not call extraction itself, so it stays testable
    and reusable independently of how a message was parsed. `customer_id`
    and `verification_data` are optional, caller-supplied hints only (per
    the API contract, a customer_id is never proof of identity).

    Returns a dict:
        {
          "decision": "AUTO" | "VERIFY" | "HUMAN" | "UNKNOWN",
          "reason": str,
          "facts": dict,            # only fixture-supported facts
          "tool_calls": [ {tool, input, result}, ... ],
          "missing_facts": [str],   # named gaps, when decision is UNKNOWN
        }
    """
    intent = extraction.get("intent")
    entities = extraction.get("entities", {})
    recorder = ToolCallRecorder()

    rule = _INTENT_RULES.get(intent)
    if rule is None:
        return _decision(
            "UNKNOWN",
            "Intent could not be classified; no rule applies.",
            facts={},
            tool_calls=recorder.calls,
            missing_facts=["intent"],
        )

    return rule(entities, recorder, customer_id, verification_data)
