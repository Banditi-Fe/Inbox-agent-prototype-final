"""Pydantic schemas for the Inbox Agent API contract.

These models describe the shape agreed in `work/backend-architecture.md`
("API contract (initial proposal)"). At this checkpoint (scaffold and
contract) they exist purely as typed documentation of the interface the
frontend can rely on. No decision logic, tool calls, or rules are wired
up yet — that happens in later increments.
"""

from typing import Any, Literal, Optional

from pydantic import BaseModel, Field

Decision = Literal["AUTO", "VERIFY", "HUMAN", "UNKNOWN"]


class MessageRequest(BaseModel):
    """Request body for POST /api/messages.

    `customer_id` is a demo lookup hint only, per the architecture doc —
    it must never be treated as proof of identity by the (future) pipeline.
    """

    message: str = Field(..., min_length=1, description="Raw inbound customer message text.")
    customer_id: Optional[str] = Field(
        default=None,
        description="Optional demo identity hint. Not proof of authorization.",
    )
    locale: Optional[str] = Field(
        default=None,
        description="Optional locale/language hint supplied by the caller.",
    )


class ToolCallRecord(BaseModel):
    """A single recorded invocation of a deterministic tool (order lookup,
    policy lookup, authorization check, etc.). Populated starting in the
    'fixtures and tools' increment — unused for now.
    """

    tool: str
    input: dict[str, Any]
    result: dict[str, Any]


class EscalationInfo(BaseModel):
    """Reference to an escalation record. Populated starting in the
    'escalation and audit' increment — unused for now.
    """

    id: str
    reason: str
    status: str


class MessageResponse(BaseModel):
    """Response body for POST /api/messages, once the pipeline exists.

    Not yet returned by the endpoint at this checkpoint — the endpoint
    currently responds 501 Not Implemented. This model documents the
    target shape for the frontend team ahead of time.
    """

    request_id: str
    language: Optional[str] = None
    intent: Optional[str] = None
    entities: dict[str, Any] = Field(default_factory=dict)
    decision: Optional[Decision] = None
    reply: Optional[str] = None
    tool_calls: list[ToolCallRecord] = Field(default_factory=list)
    escalation: Optional[EscalationInfo] = None
